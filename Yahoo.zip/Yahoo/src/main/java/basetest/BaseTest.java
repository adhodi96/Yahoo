package basetest;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import objectrepo.ObjectRepository;
import runner.Runner;

public class BaseTest extends Runner{

	public WebDriver driver;
	public ObjectRepository repo;
	public String workingdir;
	
	public void initBrowser() throws Exception{
		
		workingdir= System.getProperty("user.dir");
		repo = new ObjectRepository(workingdir+"\\application.properties");
		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"//Driver//chromedriver.exe");
		 ChromeOptions options = new ChromeOptions();
	        options.addArguments("incognito");
	        options.addArguments("test-type");
	        options.addArguments("--start-maximized");
	        options.addArguments("--disable-web-security");
	        options.addArguments("--allow-running-insecure-content");
	        driver = new ChromeDriver(options);
	        driver.manage().window().maximize();
	        driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	}
	
	public List<WebElement> waitforele(String ele){
		WebDriverWait wait = new WebDriverWait(driver, 60);
		List<WebElement> list = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath(ele)));
		return list;
	}
}

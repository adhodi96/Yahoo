package Gmail.V1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;

/**
 * Hello world!
 *
 */
public class App 
{
	
    public static void main( String[] args ) throws InterruptedException
    {
    	System.out.println( "Hello World!" );
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\ankush\\Downloads\\chromedriver_win32\\chromedriver.exe");
        //System.setProperty("webdriver.gecko.driver", "C:\\project\\geckodriver-v0.23.0-win64\\geckodriver.exe\\");
        ChromeOptions options = new ChromeOptions();
        options.addArguments("incognito");
        options.addArguments("test-type");
        options.addArguments("--start-maximized");
        options.addArguments("--disable-web-security");
        options.addArguments("--allow-running-insecure-content");
        WebDriver driver = new ChromeDriver(options);
        driver.get("https://login.yahoo.com");
        driver.manage().window().maximize();
        Thread.sleep(5000);
        driver.findElement(By.xpath("//*[@class='helper-item ']/span")).click();
        Thread.sleep(1000);
        driver.findElement(By.xpath("//*[@class='input-group']/input")).sendKeys("testing20201011@yahoo.com");
        Thread.sleep(1000);
        driver.findElement(By.xpath("//*[@class='button-container']/input")).click();
        Thread.sleep(5000);
        driver.findElement(By.xpath("//*[@id='password-container']/input")).sendKeys("testing@123");
        driver.findElement(By.xpath("//*[@class='button-container']/button")).click();
        
    }
}

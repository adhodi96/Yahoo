package runner;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.asserts.SoftAssert;

import com.cucumber.listener.ExtentProperties;
import com.cucumber.listener.Reporter;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;

//@RunWith(Cucumber.class)
@CucumberOptions(plugin = { "pretty", "html:target/cucumber",
		"com.cucumber.listener.ExtentCucumberFormatter:" }, 
features = "Feature/yahoo.feature",
glue = "stepdefination", 
dryRun = false,
monochrome = true)
public class Runner extends AbstractTestNGCucumberTests {

	// public static SoftAssert assertions;
	@BeforeClass
	public static void setup() {
		String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
		ExtentProperties extent = ExtentProperties.INSTANCE;
		extent.setReportPath("cucumber-reports/" + timeStamp.replace(":", "-").replace(".", "_") + ".html");
	}
	
	@AfterClass
	public static void writeReport() {
		String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
		String workingdir = System.getProperty("user.dir");
		Reporter.loadXMLConfig(new File(workingdir+"\\config\\extent-config.xml"));
		Reporter.setSystemInfo("Time", timeStamp);
	}
}

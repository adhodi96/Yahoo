package stepdefination;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.Properties;

import org.junit.Before;
import org.openqa.selenium.By;

import com.cucumber.listener.Reporter;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import objectrepo.ObjectRepository;

public class StepDefination extends ObjectRepository {

	String workingdir = System.getProperty("user.dir");
	Properties properties = new Properties();
	ObjectRepository repo = new ObjectRepository(workingdir + "\\application.properties");
	// int count = 1;

//	@Before
//	public String getReportConfigPath() {
//		String config = properties.getProperty(workingdir + "config\\extent-config.xml");
//		if (config != null)
//			return config;
//		else
//			throw new RuntimeException("Config Exeption") ;
//	
//	}

	@Given("^Open the browser and navigate to yahoo URL$")
	public void open_the_browser_and_navigate_to_yahoo_URL() throws Throwable {
		initBrowser();
		String url = repo.getLocator("URL");
		System.out.println("URL is: " + url);
		driver.get(repo.getLocator("URL"));
		Reporter.addStepLog("Browser is opened and URL launched");
	}

	@When("^User enter email \"(.*?)\" and password \"(.*?)\"$")
	public void user_enter_email_and_password(String arg1, String arg2) throws Throwable {
		String checkbox = repo.getLocator("checkbox");
		String email = repo.getLocator("email");
		String password = repo.getLocator("password");
		String nextbutton1 = repo.getLocator("nextbutton1");
		waitforele(checkbox);
		driver.findElement(By.xpath(checkbox)).click();
		driver.findElement(By.xpath(email)).sendKeys(arg1);
		driver.findElement(By.xpath(nextbutton1)).click();
		waitforele(password);
		driver.findElement(By.xpath(password)).sendKeys(arg2);
		Reporter.addStepLog("Login with email: " + arg1);
		Reporter.addStepLog("Entered password");
	}

	@And("^Click on login$")
	public void click_on_login() throws Throwable {
		String nextbutton2 = repo.getLocator("nextbutton2");
		waitforele(nextbutton2);
		driver.findElement(By.xpath(nextbutton2)).click();
		Reporter.addStepLog("Clicked on login button");

	}

	@Then("^User should be able to login$")
	public void user_should_be_able_to_login() throws Throwable {
		String mailicon = repo.getLocator("mailicon");
		waitforele(mailicon);
		int size = driver.findElements(By.xpath(mailicon)).size();
		if (size != 0) {
			Reporter.addStepLog("Login sucess");
		}

	}

	@Then("^Click on Mail and Compose the mail$")
	public void click_on_Mail_and_Compose_the_mail() throws Throwable {
		String mailicon = repo.getLocator("mailicon");
		String compose = repo.getLocator("compose");

		driver.findElements(By.xpath(mailicon)).get(1).click();
		Reporter.addStepLog("Clicked on mail icon");
		waitforele(compose);
		driver.findElement(By.xpath(compose)).click();
		Reporter.addStepLog("Clicked on compose mail");
	}

	@Then("^Add the email ids and subject and body$")
	public void add_the_email_ids_and_subject_and_body() throws Throwable {
		ArrayList<String> list = readExcel("Reciever");
		String tofield = repo.getLocator("tofield");
		Robot robot = new Robot();
		String subjet = repo.getLocator("subject");
		String body = repo.getLocator("body");

		String compose = repo.getLocator("compose");
		int i = 1;
		int j = 1;

		while (i < list.size()) {
			System.out.println(list.get(i));
			Reporter.addStepLog("Available id: " + list.get(i));
			waitforele(tofield);
			driver.findElement(By.xpath(tofield)).sendKeys(list.get(i));
			robot.keyPress(KeyEvent.VK_ENTER);
			driver.findElement(By.xpath(subjet)).sendKeys(j + "TEST" + i);
			driver.findElement(By.xpath(body)).sendKeys("TEST");
			Thread.sleep(2000);
			Reporter.addStepLog("Email,subject and body are entered");
			this.send_the_email();
			driver.findElement(By.xpath(compose)).click();
			i++;
		}

		j++;
	}

	@And("^Send the email$")
	public void send_the_email() throws Throwable {
		String sendbutton = repo.getLocator("sendbutton");
		driver.findElement(By.xpath(sendbutton)).click();
		Reporter.addStepLog("Clicked on send button");
	}

	@Then("^Email should get sent$")
	public void email_should_get_sent() throws Throwable {
		Reporter.addStepLog("Emails sent");
	}

	@Then("^logut and close the window$")
	public void logut_and_close_the_window() throws Throwable {
		System.out.println("TEST");
		driver.close();
		Reporter.addStepLog("Browser Closed");
	}

}

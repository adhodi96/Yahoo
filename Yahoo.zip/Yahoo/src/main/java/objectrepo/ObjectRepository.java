package objectrepo;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Properties;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import basetest.BaseTest;

public class ObjectRepository extends BaseTest {
	Properties properties;
	
	static String  testdata = System.getProperty("user.dir")+"\\data\\Reciever.xlsx";
	public ObjectRepository() {
		System.out.println("ObjextRepo constructor");
	}
	public ObjectRepository(String filepath) {
		try {
			FileInputStream locator = new FileInputStream(filepath);
			properties = new Properties();
			properties.load(locator);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public String getLocator(String elementname) {
		String data = properties.getProperty(elementname);
		System.out.println(data);
		return data;
	}
	
	public ArrayList<String> readExcel(String sheetname) throws IOException{
		System.out.println("Reading Excel");
		ArrayList<String> list = new ArrayList<String>();
		FileInputStream file = new FileInputStream(testdata);
		XSSFWorkbook wb = new XSSFWorkbook(file);
		XSSFSheet sheet = wb.getSheet(sheetname);
		Iterator<Row> row = sheet.iterator();
		while(row.hasNext()) {
			Row row1 = row.next();
			Iterator<Cell> cell = row1.cellIterator();
			while(cell.hasNext()) {
				Cell cell1 = cell.next();
				list.add(cell1.getStringCellValue());
				System.out.println(list.size());
			}
		}
		return list;
		
	}
	
	
}
